exports.__esModule = !0, exports.default = {
    CASABA_TOKEN: null,
    GQL_TOKEN: null,
    xAuthToken: null,
    appCode: null,
    tenantCode: null,
    channelCode: null,
    storeCode: null,
    cmsModel: null,
    tenantUrl: null,
    brandTittle: "品牌名",
    invoice: {
        content: "品牌名+商品",
        invoiceType: "31"
    },
    address: {
        countryName: "中国",
        nationalCode: null
    },
    calcuNumber: 5,
    pageLife: 18e5,
    BASEURL: null,
    GQLUEL: null,
    reqMax: 5,
    pay: {
        channelCode: "100",
        payment: "weixin",
        terminal: "51"
    }
};